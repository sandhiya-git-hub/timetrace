import express from 'express';
import cookieParser from 'cookie-parser';
import authRoutes from './routes/auth.routes.js';
import agentRoutes from './routes/agent.routes.js';
import deviceRoutes from './routes/device.routes.js';
import analyticsRoutes from './routes/analytics.routes.js';
import aiRoutes from './routes/ai.routes.js';

export const app = express();
app.set('trust proxy', 1);
app.use(express.json({ limit: '10mb' }));
app.use(cookieParser());

// All route files declare their full paths (/api/...), so they mount at the root.
app.use(authRoutes);
app.use(agentRoutes);
app.use(deviceRoutes);
app.use(analyticsRoutes);
app.use(aiRoutes);
