import express from 'express';
import bcrypt from 'bcryptjs';
import path from 'path';
import fs from 'fs';
import { ai, AGENT_FILE } from '../config/env.js';
import type { ChunkSummary, DailySynthesis, TelemetryEvent, DeviceState } from '../../../shared/types/chronotrace.js';
import type { UserRecord, AuthSession, DeviceRecord } from '../types/models.js';
import { getInitialUsers, getUsers, saveUsers, getAuthSessions, saveAuthSessions } from '../services/userStore.js';
import { getUserDir, defaultDeviceRecord, HEARTBEAT_TIMEOUT_MS, isAgentLive, getUserDeviceRecord, saveUserDeviceRecord, getUserTelemetry, saveUserTelemetry, getUserSessions, saveUserSessions, getUserSummary, saveUserSummary } from '../services/dataStore.js';
import { getSessionToken, getAuthenticatedUser, getDefaultUser, createSessionForUser, toUserProfile, toDeviceStatus } from '../services/authHelpers.js';

const router = express.Router();

// -------------------------------------------------------------
// WINDOWS AGENT COLLECTION SCRIPT & POWERSHELL COMMAND
// -------------------------------------------------------------

function resolveTargetUserForAgent(req: express.Request): UserRecord | null {
  // 1. Check user token in body, header, or bearer
  const token =
    req.body?.userToken ||
    req.headers['x-user-token'] ||
    (req.headers['authorization']?.startsWith('Bearer ')
      ? req.headers['authorization'].substring(7).trim()
      : null);

  const users = getUsers();
  if (token) {
    const found = users.find((u) => u.deviceToken === token || u.id === token || u.username === token);
    if (found) return found;
  }

  // 2. Check current authenticated session
  const authUser = getAuthenticatedUser(req);
  if (authUser) return authUser;

  // 3. Fallback to primary default user
  return getDefaultUser();
}

const sendAgentScript = (req: express.Request, res: express.Response) => {
  try {
    const agentFilePath = AGENT_FILE;
    let code = fs.readFileSync(agentFilePath, 'utf-8');

    let proto = (req.headers['x-forwarded-proto'] as string) || req.protocol || 'https';
    const host = req.get('host') || 'ais-dev-uakvhgsafqgajest3r52ci-548447931417.asia-southeast1.run.app';
    if (host.includes('.run.app') || host.includes('aistudio')) {
      proto = 'https';
    }
    const hostUrl = `${proto}://${host}`;

    // Read device token from query param, active session, or default
    const queryToken = (req.query.token as string) || '';
    const user = queryToken
      ? getUsers().find((u) => u.deviceToken === queryToken)
      : getAuthenticatedUser(req) || getDefaultUser();

    const deviceToken = queryToken || user?.deviceToken || '';

    code = code.replace(
      /DEFAULT_SERVER\s*=\s*["'][^"']+["']/,
      `DEFAULT_SERVER = "${hostUrl}"`
    );

    code = code.replace(
      /DEFAULT_USER_TOKEN\s*=\s*["'][^"']*["']/,
      `DEFAULT_USER_TOKEN = "${deviceToken}"`
    );

    res.setHeader('Content-Type', 'text/x-python; charset=utf-8');
    res.setHeader('Content-Disposition', 'attachment; filename="chronotrace_agent.py"');
    res.send(code);
  } catch (e: any) {
    console.error('Error serving agent script:', e);
    res.status(500).send('# Error serving agent script: ' + (e?.message || 'unknown error'));
  }
};

router.get([
  '/api/download-agent',
  '/api/download/chronotrace_agent.py',
  '/download/chronotrace_agent.py',
  '/agent.py',
  '/chronotrace_agent.py',
  '/api/agent.py',
  '/api/chronotrace_agent.py',
  '/public/agent.py',
  '/public/chronotrace_agent.py',
], sendAgentScript);

router.get('/api/agent/powershell', (req, res) => {
  let proto = (req.headers['x-forwarded-proto'] as string) || req.protocol || 'https';
  const host = req.get('host') || 'ais-dev-uakvhgsafqgajest3r52ci-548447931417.asia-southeast1.run.app';
  if (host.includes('.run.app') || host.includes('aistudio')) {
    proto = 'https';
  }
  const appOrigin = `${proto}://${host}`;
  const user = getAuthenticatedUser(req) || getDefaultUser();
  const tokenParam = user ? `?token=${encodeURIComponent(user.deviceToken)}` : '';
  const tokenFlag = user ? ` --token "${user.deviceToken}"` : '';

  const script = `cd "$env:USERPROFILE\\Downloads"; python chronotrace_agent.py`;
  res.json({ script, origin: appOrigin, deviceToken: user?.deviceToken || '' });
});

// -------------------------------------------------------------
// LIVE INGESTION FROM WINDOWS AGENT
// -------------------------------------------------------------

router.post('/api/ingest-event', (req, res) => {
  try {
    const user = resolveTargetUserForAgent(req);
    if (!user) {
      return res.status(401).json({ error: 'Unrecognized device token. Device not bound to any user account.' });
    }

    const deviceRec = getUserDeviceRecord(user.id);
    if (deviceRec.paused) {
      return res.status(409).json({
        status: 'paused',
        received: false,
        message: 'Activity collection is currently paused on the website.',
      });
    }

    const payload = req.body || {};
    const nowIso = payload.utcTimestamp || new Date().toISOString();

    // Mark heartbeat
    if (!isAgentLive(deviceRec, Date.parse(nowIso))) {
      deviceRec.connectedSince = nowIso;
    }
    deviceRec.lastHeartbeatAt = nowIso;
    deviceRec.lastSuccessfulConnectionAt = nowIso;

    if (payload.deviceName) deviceRec.deviceName = payload.deviceName;
    if (payload.os) deviceRec.os = payload.os;
    if (payload.agentVersion) deviceRec.agentVersion = payload.agentVersion;
    if (payload.timezoneOffsetMinutes !== undefined) deviceRec.timezoneOffsetMinutes = payload.timezoneOffsetMinutes;
    if (payload.timezoneName) deviceRec.timezoneName = payload.timezoneName;

    // Heartbeat-only signal
    if (payload.heartbeat && !payload.appName) {
      saveUserDeviceRecord(user.id, deviceRec);
      return res.json({ status: 'ok', received: true, heartbeat: true, user: user.username });
    }

    // Telemetry Event
    const nowTime =
      payload.localTime ||
      new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
    const nowDate =
      payload.localDate ||
      new Date().toISOString().split('T')[0];

    const deltaSec = Math.max(1, Number(payload.deltaSeconds) || 2);
    const appName = payload.appName || 'Active Window';
    const winTitle = payload.windowTitle || appName;
    const cat = payload.overrideCategory || 'Deep Work';
    const task = payload.overrideTask || `Active in ${appName}`;

    const newEvent: TelemetryEvent = {
      id: `evt_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      timestamp: nowTime,
      date: nowDate,
      recorded_at: payload.localTimestamp || nowIso,
      dwell_ms: deltaSec * 1000,
      category: cat,
      app_name: appName,
      window_title: winTitle,
      keyboard_events: 0,
    };

    const telemetry = getUserTelemetry(user.id);
    telemetry.push(newEvent);
    if (telemetry.length > 500) telemetry.shift();
    saveUserTelemetry(user.id, telemetry);

    deviceRec.lastEventTime = nowTime;
    deviceRec.lastLocalDate = nowDate;
    saveUserDeviceRecord(user.id, deviceRec);

    // Passive Activity Reconstruction: update or append cognitive session chunk
    const sessions = getUserSessions(user.id);
    const lastSession = sessions[sessions.length - 1];

    let intent: any = 'DEEP_WORK';
    if (cat === 'Learning') intent = 'LEARNING';
    else if (cat === 'Entertainment' || cat === 'Distraction') intent = 'DISTRACTION';
    else if (cat === 'Communication') intent = 'COMMUNICATION';
    else if (cat === 'Utility') intent = 'ADMIN';

    if (
      lastSession &&
      lastSession.anchor_app?.toLowerCase() === appName.toLowerCase() &&
      lastSession.dominant_category === cat
    ) {
      lastSession.duration_s += deltaSec;
      lastSession.end_time = nowTime;
      const sub = lastSession.main_events?.find((m) => m.title === winTitle);
      if (sub) {
        sub.dwell_s += deltaSec;
      } else if (lastSession.main_events) {
        lastSession.main_events.push({ app: appName, title: winTitle, dwell_s: deltaSec, keys: 0 });
      }
      lastSession.summary = `User active in ${appName}: ${winTitle} (${Math.round(lastSession.duration_s)}s duration).`;
    } else {
      const chunkId = `live_${Date.now()}_${sessions.length + 1}`;
      const newChunk: ChunkSummary = {
        chunk_id: chunkId,
        recorded_at: payload.localTimestamp || nowIso,
        duration_s: deltaSec,
        start_time: nowTime,
        end_time: nowTime,
        closed_by: 'CATEGORY_SHIFT',
        main_events: [{ app: appName, title: winTitle, dwell_s: deltaSec, keys: 0 }],
        anchor_app: appName,
        anchor_held_s: deltaSec,
        returned_to_anchor: true,
        keyboard: { total_keys: 0, rate_per_min: 0 },
        micro_behavior: {
          total_rapid_switches: 1,
          tab_flickers: 0,
          avg_micro_dwell_ms: deltaSec * 1000,
          dominant_pattern: 'NORMAL',
          unique_micro_apps: [appName],
        },
        categories_present: [cat],
        dominant_category: cat,
        copy_paste_events: 0,
        session_start_restless: false,
        intent,
        confidence: 0.95,
        primary_task: task,
        distraction_detected: cat === 'Entertainment' || cat === 'Distraction',
        distraction_type: cat === 'Entertainment' || cat === 'Distraction' ? 'rabbit_hole' : null,
        work_state: cat === 'Deep Work' || cat === 'Learning' ? 'productive' : 'settled',
        unresolved_threads: [],
        summary: `Reconstructed passive activity: ${appName} - ${winTitle} (${deltaSec}s dwell).`,
      };
      sessions.push(newChunk);
      if (sessions.length > 100) sessions.shift();
    }
    saveUserSessions(user.id, sessions);

    // Update Daily Synthesis
    const summary = getUserSummary(user.id);
    summary.date = nowDate;
    summary.total_telemetry_s = (summary.total_telemetry_s || 0) + deltaSec;
    if (cat === 'Deep Work' || cat === 'Learning') {
      summary.total_deep_work_s = (summary.total_deep_work_s || 0) + deltaSec;
    } else if (cat === 'Entertainment' || cat === 'Distraction') {
      summary.total_distraction_s = (summary.total_distraction_s || 0) + deltaSec;
      if (winTitle) {
        if (!summary.distraction_triggers) summary.distraction_triggers = [];
        if (!summary.distraction_triggers.includes(winTitle.slice(0, 45))) {
          summary.distraction_triggers.push(winTitle.slice(0, 45));
        }
      }
    }
    saveUserSummary(user.id, summary);

    res.json({ status: 'ok', received: true, user: user.username, chunkCount: sessions.length });
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});

// Sync full sessions from agent
router.post('/api/sync-sessions', (req, res) => {
  const user = resolveTargetUserForAgent(req);
  if (!user) {
    return res.status(401).json({ error: 'Unrecognized user token' });
  }
  const { sessions = [] } = req.body;
  if (Array.isArray(sessions) && sessions.length > 0) {
    console.log(`Received ${sessions.length} sessions from agent for user ${user.username}`);
  }
  res.json({ status: 'ok' });
});


export default router;
