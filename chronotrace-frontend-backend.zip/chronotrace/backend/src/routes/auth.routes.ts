import express from 'express';
import bcrypt from 'bcryptjs';
import path from 'path';
import fs from 'fs';
import { ai, AGENT_FILE } from '../config/env.js';
import type { ChunkSummary, DailySynthesis, TelemetryEvent, DeviceState } from '../../../shared/types/chronotrace.js';
import type { UserRecord, AuthSession, DeviceRecord } from '../types/models.js';
import { getInitialUsers, getUsers, saveUsers, getAuthSessions, saveAuthSessions } from '../services/userStore.js';
import { getUserDir, defaultDeviceRecord, HEARTBEAT_TIMEOUT_MS, isAgentLive, getUserDeviceRecord, saveUserDeviceRecord, getUserTelemetry, saveUserTelemetry, getUserSessions, saveUserSessions, getUserSummary, saveUserSummary } from '../services/dataStore.js';
import { getSessionToken, getAuthenticatedUser, getDefaultUser, createSessionForUser, toUserProfile, toDeviceStatus } from '../services/authHelpers.js';

const router = express.Router();

// -------------------------------------------------------------
// AUTHENTICATION ROUTES
// -------------------------------------------------------------

router.get('/api/auth/session', (req, res) => {
  const user = getAuthenticatedUser(req);
  if (user) {
    return res.json({
      authenticated: true,
      isRegistered: user.isRegistered !== false,
      hasConfiguredDevice: user.hasConfiguredDevice !== false,
      user: toUserProfile(user),
    });
  }
  return res.json({
    authenticated: false,
    isRegistered: false,
    hasConfiguredDevice: false,
    user: null,
  });
});

router.post('/api/auth/login', (req, res) => {
  const { username, password } = req.body;
  if (!username || !password) {
    return res.status(400).json({ error: 'Username and password are required.' });
  }

  const users = getUsers();
  const trimmed = String(username).trim().toLowerCase();
  const matched = users.find(
    (u) => u.username.toLowerCase() === trimmed || u.email.toLowerCase() === trimmed
  );

  if (!matched) {
    return res.status(401).json({
      error: 'Invalid username/email or password. Please provide correct details.',
    });
  }

  const passwordValid = bcrypt.compareSync(String(password), matched.passwordHash);
  if (!passwordValid) {
    return res.status(401).json({
      error: 'Invalid username/email or password. Please provide correct details.',
    });
  }

  matched.lastLogin = new Date().toISOString();
  saveUsers(users);

  const { token } = createSessionForUser(matched);
  res.cookie('chronotrace_session', token, {
    httpOnly: true,
    sameSite: 'lax',
    path: '/',
    maxAge: 30 * 24 * 3600 * 1000,
  });

  const profile = toUserProfile(matched);
  return res.json({
    success: true,
    token,
    session: {
      authenticated: true,
      isRegistered: true,
      hasConfiguredDevice: true,
      user: profile,
    },
    user: profile,
    isRegistered: true,
    hasConfiguredDevice: true,
  });
});

router.post('/api/auth/register', (req, res) => {
  const { username, email, password, name } = req.body;
  if (!username || !password || !email) {
    return res.status(400).json({ error: 'Username, email, and password are required.' });
  }

  const trimmedUsername = String(username).trim().toLowerCase();
  const trimmedEmail = String(email).trim().toLowerCase();
  const rawPassword = String(password);

  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(trimmedEmail)) {
    return res.status(400).json({ error: 'Please enter a valid email address.' });
  }

  if (trimmedUsername.length < 3) {
    return res.status(400).json({ error: 'Username must be at least 3 characters long.' });
  }

  if (rawPassword.length < 6) {
    return res.status(400).json({ error: 'Password must be at least 6 characters long.' });
  }

  const users = getUsers();
  if (users.some((u) => u.username.toLowerCase() === trimmedUsername)) {
    return res.status(409).json({ error: 'Username is already taken. Please choose another username.' });
  }

  if (users.some((u) => u.email.toLowerCase() === trimmedEmail)) {
    return res.status(409).json({ error: 'Email address is already in use. Please sign in or use another email.' });
  }

  const salt = bcrypt.genSaltSync(10);
  const passwordHash = bcrypt.hashSync(rawPassword, salt);
  const nowIso = new Date().toISOString();
  const displayName = name ? String(name).trim() : username.trim();

  const newUser: UserRecord = {
    id: `usr_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
    username: trimmedUsername,
    email: trimmedEmail,
    passwordHash,
    name: displayName,
    givenName: displayName.split(' ')[0] || displayName,
    deviceToken: `ct_dev_${trimmedUsername}_${Math.random().toString(36).slice(2, 8)}`,
    createdAt: nowIso,
    lastLogin: nowIso,
    isRegistered: false,
    hasConfiguredDevice: false,
  };

  users.push(newUser);
  saveUsers(users);

  const { token } = createSessionForUser(newUser);
  res.cookie('chronotrace_session', token, {
    httpOnly: true,
    sameSite: 'lax',
    path: '/',
    maxAge: 30 * 24 * 3600 * 1000,
  });

  const profile = toUserProfile(newUser);
  return res.status(201).json({
    success: true,
    token,
    session: {
      authenticated: true,
      isRegistered: false,
      hasConfiguredDevice: false,
      user: profile,
    },
    user: profile,
    isRegistered: false,
    hasConfiguredDevice: false,
  });
});

router.post('/api/auth/google', async (req, res) => {
  try {
    const { credential, profile } = req.body;
    let email = profile?.email;
    let name = profile?.name;
    let picture = profile?.picture;
    let sub = profile?.sub || profile?.id;

    if (credential && typeof credential === 'string') {
      try {
        const parts = credential.split('.');
        if (parts.length === 3) {
          const payloadJson = Buffer.from(parts[1], 'base64').toString('utf-8');
          const payload = JSON.parse(payloadJson);
          if (payload.email) email = payload.email;
          if (payload.name) name = payload.name;
          if (payload.picture) picture = payload.picture;
          if (payload.sub) sub = payload.sub;
        }
      } catch (tokenErr) {
        console.warn('Could not decode Google JWT, fallback to profile:', tokenErr);
      }
    }

    if (!email) {
      return res.status(400).json({ error: 'Valid Google account email is required.' });
    }

    const trimmedEmail = String(email).trim().toLowerCase();
    const users = getUsers();
    let user = users.find(
      (u) => (sub && u.googleSub === sub) || u.email.toLowerCase() === trimmedEmail
    );

    const nowIso = new Date().toISOString();
    let isFirstTime = false;

    if (!user) {
      isFirstTime = true;
      let baseUsername = trimmedEmail.split('@')[0].replace(/[^a-zA-Z0-9_-]/g, '') || 'user';
      let uniqueUsername = baseUsername;
      let counter = 1;
      while (users.some((u) => u.username.toLowerCase() === uniqueUsername)) {
        uniqueUsername = `${baseUsername}${counter++}`;
      }

      const displayName = name ? String(name).trim() : uniqueUsername;
      const salt = bcrypt.genSaltSync(10);
      user = {
        id: `usr_g_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
        username: uniqueUsername,
        email: trimmedEmail,
        passwordHash: bcrypt.hashSync(`g_oauth_${Math.random()}_${Date.now()}`, salt),
        name: displayName,
        givenName: displayName.split(' ')[0] || displayName,
        picture: picture || undefined,
        googleSub: sub || undefined,
        deviceToken: `ct_dev_${uniqueUsername}_${Math.random().toString(36).slice(2, 8)}`,
        createdAt: nowIso,
        lastLogin: nowIso,
        isRegistered: false,
        hasConfiguredDevice: false,
      };
      users.push(user);
    } else {
      user.lastLogin = nowIso;
      if (picture) user.picture = picture;
      if (name) user.name = name;
      if (sub && !user.googleSub) user.googleSub = sub;
    }
    saveUsers(users);

    const { token } = createSessionForUser(user);
    res.cookie('chronotrace_session', token, {
      httpOnly: true,
      sameSite: 'lax',
      path: '/',
      maxAge: 30 * 24 * 3600 * 1000,
    });

    const userProf = toUserProfile(user);
    return res.json({
      success: true,
      token,
      session: {
        authenticated: true,
        isRegistered: !isFirstTime,
        hasConfiguredDevice: !isFirstTime,
        user: userProf,
      },
      user: userProf,
      isRegistered: !isFirstTime,
      hasConfiguredDevice: !isFirstTime,
    });
  } catch (error: any) {
    res.status(500).json({ error: error.message || 'Authentication failed' });
  }
});

router.post('/api/auth/logout', (req, res) => {
  const token = getSessionToken(req);
  if (token) {
    const sessions = getAuthSessions();
    delete sessions[token];
    saveAuthSessions(sessions);
  }
  res.clearCookie('chronotrace_session', { path: '/' });
  res.json({ success: true });
});

router.post('/api/auth/complete-device-setup', (req, res) => {
  const user = getAuthenticatedUser(req);
  if (user) {
    user.isRegistered = true;
    user.hasConfiguredDevice = true;
    saveUsers(getUsers());
  }
  res.json({ success: true });
});


export default router;
