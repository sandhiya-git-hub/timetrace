import express from 'express';
import type { DeviceState } from '../../../shared/types/chronotrace.js';
import type { UserRecord, AuthSession, DeviceRecord } from '../types/models.js';
import { getUsers, saveUsers, getAuthSessions, saveAuthSessions } from './userStore.js';
import { isAgentLive } from './dataStore.js';

export function getSessionToken(req: express.Request): string | null {
  if (req.cookies && req.cookies['chronotrace_session']) {
    return req.cookies['chronotrace_session'];
  }
  const authHeader = req.headers['authorization'];
  if (authHeader && authHeader.startsWith('Bearer ')) {
    return authHeader.substring(7).trim();
  }
  if (req.headers['x-session-token']) {
    return String(req.headers['x-session-token']).trim();
  }
  return null;
}

export function getAuthenticatedUser(req: express.Request): UserRecord | null {
  const token = getSessionToken(req);
  if (!token) return null;

  const sessions = getAuthSessions();
  const session = sessions[token];
  if (!session) return null;

  if (new Date(session.expiresAt) <= new Date()) {
    delete sessions[token];
    saveAuthSessions(sessions);
    return null;
  }

  const users = getUsers();
  const user = users.find((u) => u.id === session.userId);
  return user || null;
}

export function getDefaultUser(): UserRecord {
  const users = getUsers();
  return users[0];
}

export function createSessionForUser(user: UserRecord): { token: string; expiresAt: string } {
  const token = `ct_sess_${Date.now()}_${Math.random().toString(36).slice(2, 12)}`;
  const expiresAt = new Date(Date.now() + 30 * 24 * 3600 * 1000).toISOString(); // 30 days
  const sessions = getAuthSessions();
  sessions[token] = {
    token,
    userId: user.id,
    createdAt: new Date().toISOString(),
    expiresAt,
  };
  saveAuthSessions(sessions);
  return { token, expiresAt };
}

export function toUserProfile(u: UserRecord) {
  return {
    id: u.id,
    username: u.username,
    email: u.email,
    name: u.name,
    givenName: u.givenName,
    picture: u.picture,
    deviceToken: u.deviceToken,
    emailVerified: true,
    lastLogin: u.lastLogin,
    isRegistered: u.isRegistered !== false,
    hasConfiguredDevice: u.hasConfiguredDevice !== false,
  };
}

export function toDeviceStatus(rec: DeviceRecord, eventCount: number = 0): DeviceState {
  const connected = isAgentLive(rec);
  let status: DeviceState['status'];
  let statusText: string;

  if (connected) {
    status = 'CONNECTED';
    statusText = 'Connected · Streaming foreground activity';
  } else if (rec.paused) {
    status = 'NOT_CONNECTED';
    statusText = 'Not Connected · Collection paused';
  } else if (rec.lastSuccessfulConnectionAt) {
    status = 'DISCONNECTED';
    statusText = `Disconnected · Last synced ${rec.lastEventTime || 'recently'}`;
  } else {
    status = 'NOT_CONNECTED';
    statusText = 'Not Connected · Waiting for the Windows agent';
  }

  return {
    connected,
    status,
    paused: rec.paused,
    deviceName: rec.deviceName,
    os: rec.os,
    agentVersion: rec.agentVersion,
    samplingInterval: rec.samplingInterval,
    lastEventTime: rec.lastEventTime,
    lastLocalDate: rec.lastLocalDate || new Date().toISOString().split('T')[0],
    eventCount,
    statusText,
    lastPing: rec.lastHeartbeatAt,
    lastHeartbeatAt: rec.lastHeartbeatAt,
    connectedSince: connected ? rec.connectedSince : null,
    lastSuccessfulConnectionAt: rec.lastSuccessfulConnectionAt,
  };
}
