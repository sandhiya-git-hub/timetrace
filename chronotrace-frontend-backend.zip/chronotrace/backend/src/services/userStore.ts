import fs from 'fs';
import path from 'path';
import bcrypt from 'bcryptjs';
import { DATA_DIR } from '../config/env.js';
import type { UserRecord, AuthSession } from '../types/models.js';

const usersPath = path.join(DATA_DIR, 'users.json');
const authSessionsPath = path.join(DATA_DIR, 'auth_sessions.json');

// Initialize users table with secure bcrypt hashes
export const getInitialUsers = (): UserRecord[] => {
  const salt = bcrypt.genSaltSync(10);
  return [
    {
      id: 'usr_sandhiya_default',
      username: 'sandhiya',
      email: 'sandhiyasankarpersonal@gmail.com',
      passwordHash: bcrypt.hashSync('password123', salt),
      name: 'Sandhiya Sankar',
      givenName: 'Sandhiya',
      deviceToken: 'ct_dev_sandhiya_live9876',
      createdAt: new Date().toISOString(),
      lastLogin: new Date().toISOString(),
      isRegistered: true,
      hasConfiguredDevice: true,
    },
    {
      id: 'usr_admin_default',
      username: 'admin',
      email: 'admin@chronotrace.local',
      passwordHash: bcrypt.hashSync('adminpassword', salt),
      name: 'ChronoTrace Administrator',
      givenName: 'Administrator',
      deviceToken: 'ct_dev_admin_live5432',
      createdAt: new Date().toISOString(),
      lastLogin: new Date().toISOString(),
      isRegistered: true,
      hasConfiguredDevice: true,
    },
  ];
};

export const getUsers = (): UserRecord[] => {
  try {
    if (fs.existsSync(usersPath)) {
      const raw = JSON.parse(fs.readFileSync(usersPath, 'utf-8'));
      if (Array.isArray(raw) && raw.length > 0) {
        let changed = false;
        // Migrate legacy plain passwords to bcrypt hashes and ensure unique id + deviceToken
        const migrated: UserRecord[] = raw.map((u: any, idx: number) => {
          let updated = { ...u };
          if (!updated.id) {
            updated.id = `usr_${updated.username || idx}_${Date.now()}`;
            changed = true;
          }
          if (!updated.deviceToken) {
            updated.deviceToken = `ct_dev_${updated.username || idx}_${Math.random().toString(36).slice(2, 8)}`;
            changed = true;
          }
          if (updated.password && !updated.passwordHash) {
            updated.passwordHash = bcrypt.hashSync(String(updated.password), 10);
            delete updated.password;
            changed = true;
          }
          if (!updated.givenName) {
            updated.givenName = (updated.name || updated.username || '').split(' ')[0] || 'User';
            changed = true;
          }
          return updated as UserRecord;
        });
        if (changed) {
          saveUsers(migrated);
        }
        return migrated;
      }
    }
  } catch (e) {
    console.error('Error reading users:', e);
  }
  const init = getInitialUsers();
  saveUsers(init);
  return init;
};

export const saveUsers = (users: UserRecord[]) => {
  try {
    fs.writeFileSync(usersPath, JSON.stringify(users, null, 2), 'utf-8');
  } catch (e) {
    console.error('Could not save users:', e);
  }
};

export const getAuthSessions = (): Record<string, AuthSession> => {
  try {
    if (fs.existsSync(authSessionsPath)) {
      return JSON.parse(fs.readFileSync(authSessionsPath, 'utf-8'));
    }
  } catch {}
  return {};
};

export const saveAuthSessions = (sessions: Record<string, AuthSession>) => {
  try {
    fs.writeFileSync(authSessionsPath, JSON.stringify(sessions, null, 2), 'utf-8');
  } catch (e) {
    console.error('Could not save auth sessions:', e);
  }
};
