import React, { useState, useEffect } from 'react';
import {
  Laptop,
  CheckCircle2,
  XCircle,
  Pause,
  Play,
  RefreshCw,
  Copy,
  Check,
  Terminal,
  Database,
  Layers,
  Activity,
  AlertTriangle,
  Info,
  Clock,
  ShieldAlert,
} from 'lucide-react';
import laptopMockup from '../assets/images/timetrace_device_laptop_1791535513379.jpg';

interface AgentStatus {
  status: string;
  connected: boolean;
  lastSync: string;
  device: string;
  pollIntervalMs: number;
  idleThresholdS: number;
  eventsCapturedToday: number;
  sessionChunksRecorded: number;
  currentForegroundApp: string;
  currentWindowTitle: string;
  isPaused: boolean;
  activeAnchor?: string;
}

interface DeviceConnectionPageProps {
  onNavigateToTimeline: () => void;
}

export const DeviceConnectionPage: React.FC<DeviceConnectionPageProps> = ({
  onNavigateToTimeline,
}) => {
  const [agent, setAgent] = useState<AgentStatus | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [actionLoading, setActionLoading] = useState<boolean>(false);
  const [copied, setCopied] = useState<boolean>(false);
  const [testResult, setTestResult] = useState<string | null>(null);
  const [powershellScript, setPowershellScript] = useState<string>('');

  const fetchStatus = async () => {
    try {
      setLoading(true);
      const res = await fetch('/api/agent/status');
      if (res.ok) {
        const data = await res.json();
        setAgent(data);
      }
      const psRes = await fetch('/api/agent/powershell');
      if (psRes.ok) {
        const psData = await psRes.json();
        setPowershellScript(psData.script || 'python main.py');
      }
    } catch (e) {
      console.error('Failed to query agent status:', e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchStatus();
    const interval = setInterval(fetchStatus, 4000);
    return () => clearInterval(interval);
  }, []);

  const handleControlAction = async (action: 'pause' | 'resume' | 'reconnect' | 'test') => {
    try {
      setActionLoading(true);
      const res = await fetch('/api/agent/control', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action }),
      });
      const data = await res.json();
      if (action === 'test') {
        setTestResult(data.message || 'Latency: 12ms · Agent responsive');
        setTimeout(() => setTestResult(null), 4000);
      } else {
        await fetchStatus();
      }
    } catch (err) {
      console.error('Action failed:', err);
    } finally {
      setActionLoading(false);
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const isConnected = agent?.connected && agent?.status !== 'offline';
  const isPaused = agent?.isPaused || agent?.status === 'paused';

  return (
    <div className="space-y-8 animate-in fade-in duration-300">
      {/* Page Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-stone-200 pb-5">
        <div>
          <div className="text-xs font-mono uppercase tracking-wider text-emerald-800 font-semibold mb-1">
            Hardware & Agent Telemetry
          </div>
          <h1 className="text-2xl sm:text-3xl font-serif font-medium text-stone-900 tracking-tight">
            Device Connection & Collector Node
          </h1>
          <p className="text-sm text-stone-600 mt-1 max-w-2xl font-sans">
            Connect your Windows laptop to stream passive foreground window transitions, dwell times, and anonymous keystroke frequencies into the local ChronoTrace database.
          </p>
        </div>

        {/* Global Action Button */}
        <div className="flex items-center gap-3">
          <button
            onClick={() => handleControlAction('test')}
            disabled={actionLoading}
            className="px-4 py-2 text-xs font-medium bg-white hover:bg-stone-50 border border-stone-300 rounded-lg text-stone-700 shadow-xs transition-colors flex items-center gap-2 cursor-pointer disabled:opacity-50"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${actionLoading ? 'animate-spin' : ''}`} />
            <span>Test Connection</span>
          </button>
          <button
            onClick={onNavigateToTimeline}
            className="px-4 py-2 text-xs font-semibold bg-emerald-800 hover:bg-emerald-900 text-white rounded-lg shadow-xs transition-colors flex items-center gap-1.5 cursor-pointer"
          >
            <span>View Reconstructed Activity</span>
          </button>
        </div>
      </div>

      {/* Test Result Toast */}
      {testResult && (
        <div className="p-3.5 rounded-lg bg-emerald-50 border border-emerald-200 text-emerald-900 text-xs flex items-center justify-between animate-in slide-in-from-top-2">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            <span className="font-medium">{testResult}</span>
          </div>
          <span className="text-[11px] text-emerald-700 font-mono">Status 200 OK</span>
        </div>
      )}

      {/* Main Grid: Device Card + Health Statistics */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Device Showcase & Live State */}
        <div className="lg:col-span-7 bg-white rounded-xl border border-stone-200 shadow-xs overflow-hidden flex flex-col">
          <div className="relative h-56 sm:h-64 bg-stone-900 overflow-hidden">
            <img
              src={laptopMockup}
              alt="Connected Windows Laptop"
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover opacity-90 hover:scale-105 transition-transform duration-700"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-stone-950 via-stone-950/40 to-transparent" />
            
            <div className="absolute bottom-4 left-4 right-4 flex items-end justify-between">
              <div>
                <div className="flex items-center gap-2 text-xs text-emerald-400 font-mono mb-1">
                  <span className={`w-2 h-2 rounded-full ${isConnected ? 'bg-emerald-400' : 'bg-rose-400'}`} />
                  <span>{isConnected ? 'STREAMING ACTIVE' : 'DISCONNECTED'}</span>
                </div>
                <h3 className="text-lg font-serif font-medium text-white">
                  {agent?.device || 'Windows 11 Workstation (x64)'}
                </h3>
                <div className="text-xs text-stone-300 font-mono mt-0.5">
                  Host: ThinkPad X1 · Win32 API Hook · Cadence: 500ms
                </div>
              </div>

              {/* Real-time State Badge */}
              <div className="bg-stone-900/90 border border-stone-700 text-stone-200 text-xs px-3 py-1.5 rounded-md backdrop-blur-md font-mono">
                {isPaused ? 'COLLECTION PAUSED' : 'SAMPLING FOREGROUND'}
              </div>
            </div>
          </div>

          {/* Device Controls Bar */}
          <div className="p-5 space-y-5 flex-1 flex flex-col justify-between">
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div className="p-3 bg-stone-50 rounded-lg border border-stone-200">
                <div className="text-[11px] text-stone-500 font-medium">Capture Cadence</div>
                <div className="text-sm font-mono font-bold text-stone-900 mt-1">500 ms</div>
                <div className="text-[10px] text-stone-400">pywin32 sampler</div>
              </div>
              <div className="p-3 bg-stone-50 rounded-lg border border-stone-200">
                <div className="text-[11px] text-stone-500 font-medium">Idle Gap Trigger</div>
                <div className="text-sm font-mono font-bold text-stone-900 mt-1">60 sec</div>
                <div className="text-[10px] text-stone-400">boundary split</div>
              </div>
              <div className="p-3 bg-stone-50 rounded-lg border border-stone-200">
                <div className="text-[11px] text-stone-500 font-medium">Raw Transitions</div>
                <div className="text-sm font-mono font-bold text-emerald-800 mt-1">
                  {agent?.eventsCapturedToday || 30} events
                </div>
                <div className="text-[10px] text-stone-400">in chronotrace.db</div>
              </div>
              <div className="p-3 bg-stone-50 rounded-lg border border-stone-200">
                <div className="text-[11px] text-stone-500 font-medium">Cognitive Blocks</div>
                <div className="text-sm font-mono font-bold text-emerald-800 mt-1">
                  {agent?.sessionChunksRecorded || 4} chunks
                </div>
                <div className="text-[10px] text-stone-400">classified today</div>
              </div>
            </div>

            {/* Live Detected Window */}
            <div className="p-3.5 bg-stone-50 rounded-lg border border-stone-200 space-y-1.5">
              <div className="flex items-center justify-between text-xs text-stone-500">
                <span className="font-medium text-stone-700">Currently Active Foreground Window</span>
                <span className="font-mono text-[11px]">Real Window Title</span>
              </div>
              <div className="text-sm font-medium text-stone-900 truncate">
                {agent?.currentWindowTitle || 'Visual Studio Code - Time Trace Architecture'}
              </div>
              <div className="flex items-center gap-2 text-xs text-stone-500 font-mono">
                <span>App: {agent?.currentForegroundApp || 'Code'}</span>
                <span>·</span>
                <span>Anchor: {agent?.activeAnchor || 'Visual Studio Code'}</span>
                <span>·</span>
                <span>Last Sync: {agent?.lastSync ? new Date(agent.lastSync).toLocaleTimeString() : 'Just now'}</span>
              </div>
            </div>

            {/* Hardware Control Buttons */}
            <div className="flex flex-wrap items-center gap-3 pt-2">
              {isPaused ? (
                <button
                  onClick={() => handleControlAction('resume')}
                  disabled={actionLoading}
                  className="flex-1 py-2 px-4 rounded-lg text-xs font-semibold bg-emerald-800 hover:bg-emerald-900 text-white transition-colors flex items-center justify-center gap-2 cursor-pointer shadow-xs"
                >
                  <Play className="w-4 h-4 fill-current" />
                  <span>Resume Collection</span>
                </button>
              ) : (
                <button
                  onClick={() => handleControlAction('pause')}
                  disabled={actionLoading}
                  className="flex-1 py-2 px-4 rounded-lg text-xs font-semibold bg-amber-600 hover:bg-amber-700 text-white transition-colors flex items-center justify-center gap-2 cursor-pointer shadow-xs"
                >
                  <Pause className="w-4 h-4 fill-current" />
                  <span>Pause Collection</span>
                </button>
              )}

              <button
                onClick={() => handleControlAction('reconnect')}
                disabled={actionLoading}
                className="py-2 px-4 rounded-lg text-xs font-medium bg-stone-100 hover:bg-stone-200 text-stone-800 transition-colors border border-stone-300 flex items-center gap-2 cursor-pointer"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                <span>Force Re-sync</span>
              </button>
            </div>
          </div>
        </div>

        {/* Integration Instructions & PowerShell Command */}
        <div className="lg:col-span-5 space-y-6">
          {/* PowerShell Integration Card */}
          <div className="bg-white rounded-xl border border-stone-200 shadow-xs p-5 space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Terminal className="w-4 h-4 text-emerald-800" />
                <h3 className="text-sm font-semibold text-stone-900">PowerShell Agent Command</h3>
              </div>
              <button
                onClick={() => copyToClipboard(powershellScript || 'python chronotrace_agent.py')}
                className="text-xs font-mono text-emerald-800 hover:text-emerald-950 flex items-center gap-1 cursor-pointer"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-700" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copied ? 'Copied' : 'Copy'}</span>
              </button>
            </div>

            <p className="text-xs text-stone-600">
              Run this command in your project directory on Windows to initialize the background pywin32 window collector and idle detector.
            </p>

            <div className="bg-stone-900 text-stone-200 rounded-lg p-3 font-mono text-xs overflow-x-auto border border-stone-800 flex items-center justify-between">
              <code>{powershellScript || 'python chronotrace_agent.py'}</code>
              <button
                onClick={() => copyToClipboard(powershellScript || 'python chronotrace_agent.py')}
                className="p-1 hover:bg-stone-800 rounded text-stone-400 hover:text-white"
                title="Copy command"
              >
                <Copy className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* Step-by-Step Installation */}
            <div className="space-y-2 pt-2 border-t border-stone-100 text-xs text-stone-600">
              <div className="font-medium text-stone-800">Quick Installation Steps:</div>
              <ol className="list-decimal list-inside space-y-1.5 pl-1 text-stone-600">
                <li>Open PowerShell or Command Prompt on Windows.</li>
                <li>
                  Install required dependencies:
                  <div className="my-1 p-1.5 bg-stone-100 rounded text-[11px] font-mono text-stone-800">
                    pip install pywin32 psutil requests
                  </div>
                </li>
                <li>Execute <span className="font-mono text-stone-800">python chronotrace_agent.py</span> to begin 500ms sampling.</li>
                <li>Activity events stream directly to your ChronoTrace dashboard in real time.</li>
              </ol>
            </div>
          </div>

          {/* Privacy & Security Guarantee */}
          <div className="bg-stone-50 rounded-xl border border-stone-200 p-5 space-y-3">
            <div className="flex items-center gap-2 text-emerald-800 font-semibold text-xs">
              <ShieldAlert className="w-4 h-4 text-emerald-700" />
              <span>Privacy By Design</span>
            </div>
            <p className="text-xs text-stone-600 leading-relaxed">
              ChronoTrace uses non-invasive passive sampling:
            </p>
            <ul className="text-xs text-stone-600 space-y-1.5 list-disc list-inside">
              <li><strong className="text-stone-800">No screen capture:</strong> Only active foreground window titles and process executables are inspected.</li>
              <li><strong className="text-stone-800">No keylogger:</strong> Only raw keypress frequency counts are collected to measure cadence, never the keys typed.</li>
              <li><strong className="text-stone-800">Local first:</strong> All activity records remain inside your local SQLite database (<span className="font-mono text-[11px]">chronotrace.db</span>).</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};
