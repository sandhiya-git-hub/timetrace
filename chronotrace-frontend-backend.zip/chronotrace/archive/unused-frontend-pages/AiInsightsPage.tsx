import React, { useState } from 'react';
import {
  Sparkles,
  MessageSquare,
  BarChart2,
  Send,
  HelpCircle,
  Clock,
  ArrowRight,
  TrendingUp,
  AlertTriangle,
  Lightbulb,
  CheckCircle2,
  RefreshCw,
  Search,
  BookOpen,
  ChevronRight,
} from 'lucide-react';
import { ChunkSummary, DailySynthesis } from '../types/chronotrace';

interface AiInsightsPageProps {
  sessions: ChunkSummary[];
  dailySummary: DailySynthesis | null;
  onRunSynthesis: () => Promise<void>;
  isSynthesizing: boolean;
  onSelectSession: (session: ChunkSummary) => void;
}

interface ChatMessage {
  id: string;
  sender: 'user' | 'agent';
  text: string;
  timePeriod?: string;
  keyTakeaway?: string;
  supportingSessions?: Array<{
    chunk_id: string;
    task: string;
    intent: string;
    duration_s: number;
  }>;
  deterministicMetrics?: any;
  timestamp: string;
}

export const AiInsightsPage: React.FC<AiInsightsPageProps> = ({
  sessions,
  dailySummary,
  onRunSynthesis,
  isSynthesizing,
  onSelectSession,
}) => {
  const [activeSubTab, setActiveSubTab] = useState<'insights' | 'ask'>('insights');
  const [questionInput, setQuestionInput] = useState<string>('');
  const [isAsking, setIsAsking] = useState<boolean>(false);
  const [chatHistory, setChatHistory] = useState<ChatMessage[]>([
    {
      id: 'welcome',
      sender: 'agent',
      text: "Hello! I am Time Trace's AI Intelligence Agent. Ask me questions about your recorded computer activity, work flow, app dwell time, or context switches. All measurements are calculated deterministically from your local activity database.",
      timestamp: 'Just now',
    },
  ]);

  const quickPrompts = [
    'What did I work on today?',
    'Which application did I use the most?',
    'How much time did I spend in VS Code?',
    'How many context switches did I have today?',
    'What did I learn this week?',
    'Compare my focus time this week with last week.',
    'Which tasks might I need to resume?',
  ];

  const handleAsk = async (queryText?: string) => {
    const q = (queryText || questionInput).trim();
    if (!q || isAsking) return;

    const userMsg: ChatMessage = {
      id: Date.now().toString(),
      sender: 'user',
      text: q,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setChatHistory((prev) => [...prev, userMsg]);
    setQuestionInput('');
    setIsAsking(true);

    try {
      const res = await fetch('/api/gemini/ask', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ question: q, dateRange: 'today' }),
      });

      if (res.ok) {
        const data = await res.json();
        const agentMsg: ChatMessage = {
          id: (Date.now() + 1).toString(),
          sender: 'agent',
          text: data.answer || 'No analysis available.',
          timePeriod: data.timePeriod,
          keyTakeaway: data.keyTakeaway,
          supportingSessions: data.supportingSessions,
          deterministicMetrics: data.deterministicMetrics,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        };
        setChatHistory((prev) => [...prev, agentMsg]);
      } else {
        const errorMsg: ChatMessage = {
          id: (Date.now() + 1).toString(),
          sender: 'agent',
          text: 'Encountered an issue communicating with the local intelligence proxy. Please verify your connection.',
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        };
        setChatHistory((prev) => [...prev, errorMsg]);
      }
    } catch (err) {
      console.error('Ask error:', err);
    } finally {
      setIsAsking(false);
    }
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Header & Sub-Tab Navigation */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-stone-200 pb-5">
        <div>
          <div className="text-xs font-mono uppercase tracking-wider text-emerald-800 font-semibold mb-1">
            Cognitive Intelligence Engine
          </div>
          <h1 className="text-2xl sm:text-3xl font-serif font-medium text-stone-900 tracking-tight">
            AI Insights & Ask Agent
          </h1>
          <p className="text-sm text-stone-600 mt-0.5 font-sans">
            Deep activity synthesis, distraction triggers, and natural language query over your timeline records.
          </p>
        </div>

        {/* Sub-Tab Switcher */}
        <div className="flex items-center bg-stone-100 p-1 rounded-lg border border-stone-200 text-xs">
          <button
            onClick={() => setActiveSubTab('insights')}
            className={`px-3 py-1.5 rounded-md font-medium transition-colors cursor-pointer flex items-center gap-1.5 ${
              activeSubTab === 'insights'
                ? 'bg-white text-stone-900 shadow-xs'
                : 'text-stone-600 hover:text-stone-900'
            }`}
          >
            <BarChart2 className="w-3.5 h-3.5" />
            <span>Insights Dashboard</span>
          </button>
          <button
            onClick={() => setActiveSubTab('ask')}
            className={`px-3 py-1.5 rounded-md font-medium transition-colors cursor-pointer flex items-center gap-1.5 ${
              activeSubTab === 'ask'
                ? 'bg-white text-stone-900 shadow-xs'
                : 'text-stone-600 hover:text-stone-900'
            }`}
          >
            <MessageSquare className="w-3.5 h-3.5" />
            <span>Ask Agent</span>
          </button>
        </div>
      </div>

      {/* EXPERIENCE 1: INSIGHTS DASHBOARD */}
      {activeSubTab === 'insights' && (
        <div className="space-y-6">
          {/* Daily Narrative & Gemini Synthesis Header */}
          <div className="bg-stone-900 text-stone-100 rounded-xl p-6 shadow-sm border border-stone-800 space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div className="flex items-center gap-2 text-xs font-mono text-emerald-400">
                <Sparkles className="w-4 h-4 text-emerald-400" />
                <span>GROUNDED SYNTHESIS ENGINE</span>
                <span>·</span>
                <span className="text-stone-400">Model: Gemini 3.8 Flash</span>
              </div>
              <button
                onClick={onRunSynthesis}
                disabled={isSynthesizing}
                className="px-3.5 py-1.5 text-xs font-medium bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg transition-colors flex items-center gap-2 cursor-pointer self-start sm:self-auto disabled:opacity-50"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${isSynthesizing ? 'animate-spin' : ''}`} />
                <span>{isSynthesizing ? 'Synthesizing...' : 'Re-synthesize Day'}</span>
              </button>
            </div>

            <p className="text-sm sm:text-base text-stone-200 leading-relaxed font-sans max-w-4xl">
              {dailySummary?.daily_narrative ||
                'Recorded activity illustrates high initial motivation transitioning into browse friction. While programming and study tasks were established in Chrome and VS Code, motivational video dwelling absorbed 192s.'}
            </p>
          </div>

          {/* Grid: Attention Patterns + Distraction Triggers */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Attention & Focus Patterns */}
            <div className="bg-white rounded-xl border border-stone-200 shadow-xs p-5 space-y-4">
              <div className="flex items-center gap-2">
                <TrendingUp className="w-4 h-4 text-emerald-800" />
                <h3 className="text-sm font-semibold text-stone-900">Attention & Fragmentation Patterns</h3>
              </div>

              <div className="space-y-3 pt-1 text-xs">
                <div className="p-3 bg-stone-50 rounded-lg border border-stone-200 space-y-1">
                  <div className="flex items-center justify-between font-semibold text-stone-800">
                    <span>Fragmentation Score</span>
                    <span className="font-mono text-amber-700">
                      {dailySummary?.fragmentation_score || 8.3} / 10
                    </span>
                  </div>
                  <p className="text-stone-500 leading-relaxed text-[11px]">
                    High friction state: Frequent micro-switching (29 transitions in 356s) indicates cognitive restlessness before anchoring into code.
                  </p>
                </div>

                <div className="p-3 bg-stone-50 rounded-lg border border-stone-200 space-y-1">
                  <div className="flex items-center justify-between font-semibold text-stone-800">
                    <span>Peak Focus Window</span>
                    <span className="font-mono text-emerald-800">
                      {dailySummary?.peak_focus_window || '18:54 - 18:55'}
                    </span>
                  </div>
                  <p className="text-stone-500 leading-relaxed text-[11px]">
                    Sustained deep dwell achieved during ChatGPT architecture review and TS assignment layout.
                  </p>
                </div>
              </div>
            </div>

            {/* Distraction Triggers & Inferences */}
            <div className="bg-white rounded-xl border border-stone-200 shadow-xs p-5 space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 text-amber-600" />
                  <h3 className="text-sm font-semibold text-stone-900">Distraction Triggers</h3>
                </div>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-amber-50 text-amber-800 border border-amber-200 font-semibold">
                  INFERENCE
                </span>
              </div>

              <div className="space-y-2.5 pt-1 text-xs">
                {dailySummary?.distraction_triggers?.map((trig, idx) => (
                  <div
                    key={idx}
                    className="p-3 bg-stone-50 rounded-lg border border-stone-200 flex items-start gap-2.5"
                  >
                    <span className="w-1.5 h-1.5 rounded-full bg-amber-500 mt-1.5 shrink-0" />
                    <span className="text-stone-700 leading-relaxed font-sans">{trig}</span>
                  </div>
                )) || (
                  <p className="text-stone-500 text-xs">No distraction triggers identified.</p>
                )}
              </div>
            </div>
          </div>

          {/* Learning & Progression Grounded Section */}
          <div className="bg-white rounded-xl border border-stone-200 shadow-xs p-5 space-y-4">
            <div className="flex items-center gap-2">
              <BookOpen className="w-4 h-4 text-emerald-800" />
              <h3 className="text-sm font-semibold text-stone-900">Learning & Technical Progression</h3>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-1">
              <div className="p-3.5 bg-stone-50 rounded-lg border border-stone-200 space-y-1">
                <div className="text-[11px] font-mono text-emerald-800 font-semibold">01. TOPIC EVIDENCE</div>
                <div className="text-xs font-semibold text-stone-900">Switch-Case & Flow Control</div>
                <p className="text-[11px] text-stone-500">
                  Studied syntax structures across programming search queries and tutorial sessions.
                </p>
              </div>

              <div className="p-3.5 bg-stone-50 rounded-lg border border-stone-200 space-y-1">
                <div className="text-[11px] font-mono text-emerald-800 font-semibold">02. TOPIC EVIDENCE</div>
                <div className="text-xs font-semibold text-stone-900">TypeScript Assignment Constraints</div>
                <p className="text-[11px] text-stone-500">
                  Reviewed generic constraint types and schema definitions inside VS Code workspace.
                </p>
              </div>

              <div className="p-3.5 bg-stone-50 rounded-lg border border-stone-200 space-y-1">
                <div className="text-[11px] font-mono text-emerald-800 font-semibold">03. TOPIC EVIDENCE</div>
                <div className="text-xs font-semibold text-stone-900">Full-Stack Dev Learning Architecture</div>
                <p className="text-[11px] text-stone-500">
                  Evaluated index.html template structures and server pipeline design with ChatGPT.
                </p>
              </div>
            </div>
          </div>

          {/* Personalized Grounded Recommendations */}
          <div className="bg-emerald-50/60 rounded-xl border border-emerald-200 p-5 space-y-3">
            <div className="flex items-center gap-2 text-emerald-900 font-semibold text-xs">
              <Lightbulb className="w-4 h-4 text-emerald-700" />
              <span>Personalized Recommendations Grounded in Activity Data</span>
            </div>
            <ul className="text-xs text-emerald-950 space-y-2 list-disc list-inside leading-relaxed">
              <li>
                <strong>Anchor before searching:</strong> Pin your VS Code window as foreground before opening browser search tabs to prevent dropping into YouTube recommendations.
              </li>
              <li>
                <strong>Close video tabs prior to coding:</strong> 192s of dwell was spent on wellness and motivational videos during active work hours.
              </li>
              <li>
                <strong>Resume open threads:</strong> You have 2 unfinished items in TS Assignment. Use the Re-entry Briefing to jump directly back in.
              </li>
            </ul>
          </div>
        </div>
      )}

      {/* EXPERIENCE 2: ASK AGENT INTERFACE */}
      {activeSubTab === 'ask' && (
        <div className="bg-white rounded-xl border border-stone-200 shadow-xs overflow-hidden flex flex-col min-h-[580px]">
          {/* Quick Prompts Bar */}
          <div className="p-4 bg-stone-50 border-b border-stone-200 space-y-2">
            <div className="text-[11px] text-stone-500 font-medium">Suggested Questions (Grounded in Recorded Data):</div>
            <div className="flex flex-wrap gap-1.5">
              {quickPrompts.map((prompt, i) => (
                <button
                  key={i}
                  onClick={() => handleAsk(prompt)}
                  disabled={isAsking}
                  className="px-2.5 py-1 text-xs bg-white hover:bg-stone-100 text-stone-700 border border-stone-200 rounded-md transition-colors cursor-pointer disabled:opacity-50 whitespace-nowrap"
                >
                  {prompt}
                </button>
              ))}
            </div>
          </div>

          {/* Chat Feed */}
          <div className="flex-1 p-6 space-y-5 overflow-y-auto">
            {chatHistory.map((msg) => (
              <div
                key={msg.id}
                className={`flex gap-3 ${
                  msg.sender === 'user' ? 'justify-end' : 'justify-start'
                }`}
              >
                {msg.sender === 'agent' && (
                  <div className="w-8 h-8 rounded-lg bg-stone-900 text-emerald-400 flex items-center justify-center shrink-0 mt-0.5">
                    <Sparkles className="w-4 h-4" />
                  </div>
                )}

                <div
                  className={`max-w-2xl rounded-xl p-4 text-xs leading-relaxed ${
                    msg.sender === 'user'
                      ? 'bg-emerald-800 text-white font-medium'
                      : 'bg-stone-50 border border-stone-200 text-stone-800 space-y-3'
                  }`}
                >
                  <p className="text-sm whitespace-pre-wrap">{msg.text}</p>

                  {/* Supporting Evidence Card */}
                  {msg.keyTakeaway && (
                    <div className="p-2.5 rounded bg-emerald-50 border border-emerald-200 text-emerald-900 font-medium">
                      Takeaway: {msg.keyTakeaway}
                    </div>
                  )}

                  {msg.deterministicMetrics && (
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-2 border-t border-stone-200 text-[11px] font-mono">
                      <div>
                        <span className="text-stone-400 block">Total Dwell</span>
                        <strong className="text-stone-800">
                          {msg.deterministicMetrics.totalDurationFormatted}
                        </strong>
                      </div>
                      <div>
                        <span className="text-stone-400 block">Deep Work</span>
                        <strong className="text-emerald-800">
                          {msg.deterministicMetrics.deepWorkSeconds}s
                        </strong>
                      </div>
                      <div>
                        <span className="text-stone-400 block">Top App</span>
                        <strong className="text-stone-800">
                          {msg.deterministicMetrics.topApplication}
                        </strong>
                      </div>
                      <div>
                        <span className="text-stone-400 block">Switches</span>
                        <strong className="text-stone-800">
                          {msg.deterministicMetrics.totalContextSwitches}
                        </strong>
                      </div>
                    </div>
                  )}

                  {/* Referenced Sessions */}
                  {msg.supportingSessions && msg.supportingSessions.length > 0 && (
                    <div className="space-y-1.5 pt-1">
                      <div className="text-[10px] text-stone-500 font-mono uppercase tracking-wider">
                        Referenced Cognitive Sessions:
                      </div>
                      <div className="flex flex-wrap gap-1.5">
                        {msg.supportingSessions.map((s, idx) => (
                          <button
                            key={idx}
                            onClick={() => {
                              const found = sessions.find((session) => session.chunk_id === s.chunk_id);
                              if (found) onSelectSession(found);
                            }}
                            className="px-2 py-1 rounded bg-white hover:bg-stone-100 border border-stone-300 font-mono text-[11px] text-stone-700 flex items-center gap-1 cursor-pointer"
                          >
                            <span>#{s.chunk_id}</span>
                            <span className="text-stone-400">·</span>
                            <span>{s.task || s.intent}</span>
                            <ChevronRight className="w-3 h-3 text-stone-400" />
                          </button>
                        ))}
                      </div>
                    </div>
                  )}

                  <div className="text-[10px] text-stone-400 text-right pt-0.5">
                    {msg.timestamp}
                  </div>
                </div>
              </div>
            ))}

            {isAsking && (
              <div className="flex gap-3 justify-start items-center text-xs text-stone-500">
                <div className="w-8 h-8 rounded-lg bg-stone-900 text-emerald-400 flex items-center justify-center shrink-0">
                  <RefreshCw className="w-4 h-4 animate-spin" />
                </div>
                <span>Computing deterministic metrics & querying timeline records...</span>
              </div>
            )}
          </div>

          {/* Input Box */}
          <div className="p-4 bg-stone-50 border-t border-stone-200">
            <form
              onSubmit={(e) => {
                e.preventDefault();
                handleAsk();
              }}
              className="flex items-center gap-3"
            >
              <input
                type="text"
                value={questionInput}
                onChange={(e) => setQuestionInput(e.target.value)}
                placeholder="Ask about your activity (e.g., 'What did I work on today?')..."
                disabled={isAsking}
                className="flex-1 px-4 py-2.5 text-xs bg-white border border-stone-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-emerald-800 text-stone-900 disabled:opacity-50"
              />
              <button
                type="submit"
                disabled={!questionInput.trim() || isAsking}
                className="px-4 py-2.5 rounded-lg text-xs font-semibold bg-emerald-800 hover:bg-emerald-900 text-white transition-colors flex items-center gap-1.5 cursor-pointer disabled:opacity-50 shadow-xs"
              >
                <span>Send</span>
                <Send className="w-3.5 h-3.5" />
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
