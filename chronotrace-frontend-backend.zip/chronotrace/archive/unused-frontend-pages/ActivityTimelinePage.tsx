import React, { useState, useMemo } from 'react';
import {
  Clock,
  Search,
  Filter,
  ArrowUpDown,
  Laptop,
  CheckCircle2,
  AlertTriangle,
  Layers,
  ChevronRight,
  X,
  ExternalLink,
  Keyboard,
  Compass,
  Sparkles,
  RefreshCw,
  Edit2,
  Check,
} from 'lucide-react';
import { ChunkSummary, IntentLabel } from '../types/chronotrace';

interface ActivityTimelinePageProps {
  sessions: ChunkSummary[];
  onCorrectIntent: (chunkId: string, newIntent: IntentLabel) => Promise<void>;
  onRefresh: () => Promise<void>;
  selectedSession: ChunkSummary | null;
  onSelectSession: (session: ChunkSummary | null) => void;
}

export const ActivityTimelinePage: React.FC<ActivityTimelinePageProps> = ({
  sessions,
  onCorrectIntent,
  onRefresh,
  selectedSession,
  onSelectSession,
}) => {
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [categoryFilter, setCategoryFilter] = useState<string>('ALL');
  const [intentFilter, setIntentFilter] = useState<string>('ALL');
  const [sortBy, setSortBy] = useState<'newest' | 'oldest' | 'longest'>('newest');
  const [isRefreshing, setIsRefreshing] = useState<boolean>(false);
  const [editingIntent, setEditingIntent] = useState<boolean>(false);
  const [selectedIntentValue, setSelectedIntentValue] = useState<IntentLabel>('DEEP_WORK');

  const categories = useMemo(() => {
    const set = new Set<string>();
    sessions.forEach((s) => {
      if (s.dominant_category) set.add(s.dominant_category);
      s.categories_present?.forEach((c) => set.add(c));
    });
    return Array.from(set);
  }, [sessions]);

  const filteredSessions = useMemo(() => {
    return sessions
      .filter((s) => {
        // Search query filter
        if (searchQuery.trim()) {
          const q = searchQuery.toLowerCase();
          const matchApp = s.anchor_app?.toLowerCase().includes(q);
          const matchTask = s.primary_task?.toLowerCase().includes(q);
          const matchSummary = s.summary?.toLowerCase().includes(q);
          const matchEvents = s.main_events?.some(
            (e) => e.app.toLowerCase().includes(q) || e.title.toLowerCase().includes(q)
          );
          if (!matchApp && !matchTask && !matchSummary && !matchEvents) return false;
        }

        // Category filter
        if (categoryFilter !== 'ALL') {
          if (
            s.dominant_category !== categoryFilter &&
            !s.categories_present?.includes(categoryFilter)
          ) {
            return false;
          }
        }

        // Intent filter
        if (intentFilter !== 'ALL' && s.intent !== intentFilter) {
          return false;
        }

        return true;
      })
      .sort((a, b) => {
        if (sortBy === 'newest') return b.chunk_id.localeCompare(a.chunk_id);
        if (sortBy === 'oldest') return a.chunk_id.localeCompare(b.chunk_id);
        if (sortBy === 'longest') return (b.duration_s || 0) - (a.duration_s || 0);
        return 0;
      });
  }, [sessions, searchQuery, categoryFilter, intentFilter, sortBy]);

  const handleManualRefresh = async () => {
    setIsRefreshing(true);
    await onRefresh();
    setTimeout(() => setIsRefreshing(false), 500);
  };

  const formatSeconds = (s: number) => {
    if (s < 60) return `${Math.round(s)}s`;
    const m = Math.floor(s / 60);
    const sec = Math.round(s % 60);
    return `${m}m ${sec > 0 ? `${sec}s` : ''}`;
  };

  const handleIntentSave = async () => {
    if (!selectedSession) return;
    await onCorrectIntent(selectedSession.chunk_id, selectedIntentValue);
    setEditingIntent(false);
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Header & Controls */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-stone-200 pb-5">
        <div>
          <div className="text-xs font-mono uppercase tracking-wider text-emerald-800 font-semibold mb-1">
            Reconstructed Activity Stream
          </div>
          <h1 className="text-2xl sm:text-3xl font-serif font-medium text-stone-900 tracking-tight">
            Live Activity Timeline & Cognitive Chunks
          </h1>
          <p className="text-sm text-stone-600 mt-0.5 font-sans">
            Continuous passive window transitions clustered into high-integrity work sessions with micro-event pattern tracking.
          </p>
        </div>

        {/* Live sync button */}
        <div className="flex items-center gap-3">
          <button
            onClick={handleManualRefresh}
            disabled={isRefreshing}
            className="px-3.5 py-2 text-xs font-medium bg-white hover:bg-stone-50 border border-stone-300 rounded-lg text-stone-700 shadow-xs transition-colors flex items-center gap-2 cursor-pointer disabled:opacity-50"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isRefreshing ? 'animate-spin' : ''}`} />
            <span>Sync Activity Stream</span>
          </button>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white rounded-xl border border-stone-200 shadow-xs p-4 space-y-3">
        <div className="flex flex-col md:flex-row items-stretch md:items-center gap-3">
          {/* Search Box */}
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-stone-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search by application, task title, or window..."
              className="w-full pl-9 pr-4 py-2 text-xs bg-stone-50 border border-stone-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-emerald-800 text-stone-900"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-stone-400 hover:text-stone-600"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {/* Category Dropdown */}
          <select
            value={categoryFilter}
            onChange={(e) => setCategoryFilter(e.target.value)}
            className="text-xs bg-stone-50 border border-stone-200 rounded-lg px-3 py-2 text-stone-700 focus:outline-none cursor-pointer"
          >
            <option value="ALL">All Categories</option>
            {categories.map((cat) => (
              <option key={cat} value={cat}>
                {cat}
              </option>
            ))}
          </select>

          {/* Intent Dropdown */}
          <select
            value={intentFilter}
            onChange={(e) => setIntentFilter(e.target.value)}
            className="text-xs bg-stone-50 border border-stone-200 rounded-lg px-3 py-2 text-stone-700 focus:outline-none cursor-pointer"
          >
            <option value="ALL">All Cognitive Intents</option>
            <option value="DEEP_WORK">Deep Work</option>
            <option value="LEARNING">Learning</option>
            <option value="DISTRACTION">Distraction</option>
            <option value="DISTRACTION_BREAK">Distraction Break</option>
            <option value="COMMUNICATION">Communication</option>
          </select>

          {/* Sort Dropdown */}
          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value as any)}
            className="text-xs bg-stone-50 border border-stone-200 rounded-lg px-3 py-2 text-stone-700 focus:outline-none cursor-pointer"
          >
            <option value="newest">Newest First</option>
            <option value="oldest">Oldest First</option>
            <option value="longest">Longest Duration</option>
          </select>
        </div>

        {/* Active filter badges / counts */}
        <div className="flex items-center justify-between text-xs text-stone-500 pt-1 border-t border-stone-100">
          <div>
            Showing <strong className="text-stone-800">{filteredSessions.length}</strong> of{' '}
            <strong className="text-stone-800">{sessions.length}</strong> reconstructed sessions
          </div>
          {(categoryFilter !== 'ALL' || intentFilter !== 'ALL' || searchQuery) && (
            <button
              onClick={() => {
                setCategoryFilter('ALL');
                setIntentFilter('ALL');
                setSearchQuery('');
              }}
              className="text-emerald-800 hover:text-emerald-950 font-medium cursor-pointer"
            >
              Reset Filters
            </button>
          )}
        </div>
      </div>

      {/* Main Content: Timeline List & Session Inspector */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Timeline Sessions Column */}
        <div
          className={`${
            selectedSession ? 'lg:col-span-7' : 'lg:col-span-12'
          } space-y-3 transition-all duration-300`}
        >
          {filteredSessions.length === 0 ? (
            <div className="p-12 text-center bg-white rounded-xl border border-stone-200 shadow-xs space-y-3">
              <Laptop className="w-8 h-8 text-stone-400 mx-auto" />
              <h3 className="text-sm font-semibold text-stone-900">No activity sessions match filter</h3>
              <p className="text-xs text-stone-500 max-w-sm mx-auto">
                Try adjusting your search query, or ensure the Windows background agent is actively collecting window transitions.
              </p>
            </div>
          ) : (
            filteredSessions.map((session, idx) => {
              const isSelected = selectedSession?.chunk_id === session.chunk_id;
              const isDeep = session.intent === 'DEEP_WORK' || session.intent === 'LEARNING';
              const isDistraction =
                session.intent === 'DISTRACTION' || session.intent === 'DISTRACTION_BREAK';

              return (
                <div
                  key={session.chunk_id}
                  onClick={() => onSelectSession(session)}
                  className={`p-4 rounded-xl border transition-all duration-200 cursor-pointer bg-white relative ${
                    isSelected
                      ? 'border-emerald-700 shadow-sm ring-1 ring-emerald-700'
                      : 'border-stone-200 hover:border-stone-300 shadow-xs'
                  }`}
                >
                  <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3">
                    <div className="space-y-1.5 flex-1 min-w-0">
                      {/* Top metadata strip */}
                      <div className="flex items-center gap-2 text-xs text-stone-500 font-mono">
                        <span className="font-semibold text-stone-700">{session.start_time}</span>
                        <span>·</span>
                        <span>Duration: {formatSeconds(session.duration_s)}</span>
                        <span>·</span>
                        <span className="text-stone-400">{session.dominant_category}</span>
                      </div>

                      {/* Primary Task & Anchor */}
                      <h3 className="text-base font-semibold text-stone-900 tracking-tight truncate">
                        {session.primary_task || session.anchor_app || 'Autonomous Activity Chunk'}
                      </h3>

                      {/* Summary sentence */}
                      <p className="text-xs text-stone-600 line-clamp-2 leading-relaxed">
                        {session.summary || 'Recorded continuous window dwell and transitions.'}
                      </p>

                      {/* Window events pill counts */}
                      <div className="flex flex-wrap items-center gap-2 pt-1">
                        <span className="text-[11px] font-mono text-stone-500">
                          {session.main_events?.length || 1} windows
                        </span>
                        <span className="text-stone-300">/</span>
                        <span className="text-[11px] font-mono text-stone-500">
                          {session.micro_behavior?.total_rapid_switches || 0} rapid switches
                        </span>
                        {session.anchor_app && (
                          <>
                            <span className="text-stone-300">/</span>
                            <span className="text-[11px] font-mono text-emerald-800">
                              Anchor: {session.anchor_app}
                            </span>
                          </>
                        )}
                        {session.user_corrected && (
                          <>
                            <span className="text-stone-300">/</span>
                            <span className="text-[10px] font-mono text-sky-700 font-medium">
                              User Corrected
                            </span>
                          </>
                        )}
                      </div>
                    </div>

                    {/* Right Intent Badge & Action */}
                    <div className="flex sm:flex-col items-center sm:items-end justify-between sm:justify-start gap-2 shrink-0">
                      <span
                        className={`text-xs font-mono font-bold px-2.5 py-1 rounded-md tracking-wider ${
                          isDeep
                            ? 'bg-emerald-100 text-emerald-900 border border-emerald-200'
                            : isDistraction
                            ? 'bg-amber-100 text-amber-900 border border-amber-200'
                            : 'bg-stone-100 text-stone-800 border border-stone-200'
                        }`}
                      >
                        {session.intent}
                      </span>
                      <div className="flex items-center gap-1 text-[11px] text-stone-400 group-hover:text-stone-600">
                        <span>Inspect</span>
                        <ChevronRight className="w-3.5 h-3.5" />
                      </div>
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Session Inspector Drawer / Details */}
        {selectedSession && (
          <div className="lg:col-span-5 bg-white rounded-xl border border-stone-200 shadow-md p-5 space-y-5 sticky top-20 animate-in slide-in-from-right-4 duration-300">
            {/* Inspector Header */}
            <div className="flex items-start justify-between border-b border-stone-200 pb-3">
              <div>
                <div className="text-[11px] font-mono uppercase text-emerald-800 font-semibold tracking-wider">
                  Session Inspector
                </div>
                <h3 className="text-base font-serif font-medium text-stone-900 mt-0.5">
                  Chunk #{selectedSession.chunk_id}
                </h3>
              </div>
              <button
                onClick={() => onSelectSession(null)}
                className="p-1 hover:bg-stone-100 rounded text-stone-400 hover:text-stone-600 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Quick Metrics */}
            <div className="grid grid-cols-3 gap-2 text-center">
              <div className="p-2.5 bg-stone-50 rounded-lg border border-stone-200">
                <div className="text-[10px] text-stone-500 font-medium">Duration</div>
                <div className="text-sm font-mono font-bold text-stone-900 mt-0.5">
                  {formatSeconds(selectedSession.duration_s)}
                </div>
              </div>
              <div className="p-2.5 bg-stone-50 rounded-lg border border-stone-200">
                <div className="text-[10px] text-stone-500 font-medium">Transitions</div>
                <div className="text-sm font-mono font-bold text-stone-900 mt-0.5">
                  {selectedSession.main_events?.length || 1}
                </div>
              </div>
              <div className="p-2.5 bg-stone-50 rounded-lg border border-stone-200">
                <div className="text-[10px] text-stone-500 font-medium">Rapid Switches</div>
                <div className="text-sm font-mono font-bold text-stone-900 mt-0.5">
                  {selectedSession.micro_behavior?.total_rapid_switches || 0}
                </div>
              </div>
            </div>

            {/* Inferred Cognitive Intent & Correction */}
            <div className="space-y-2 p-3 bg-stone-50 rounded-lg border border-stone-200">
              <div className="flex items-center justify-between text-xs">
                <span className="font-semibold text-stone-700">Cognitive Classification</span>
                <span className="font-mono text-stone-500 text-[11px]">
                  Confidence: {Math.round((selectedSession.confidence || 0.9) * 100)}%
                </span>
              </div>

              {!editingIntent ? (
                <div className="flex items-center justify-between pt-1">
                  <span className="font-mono font-bold text-xs text-stone-900">
                    {selectedSession.intent}
                  </span>
                  <button
                    onClick={() => {
                      setSelectedIntentValue(selectedSession.intent || 'DEEP_WORK');
                      setEditingIntent(true);
                    }}
                    className="text-xs text-emerald-800 hover:text-emerald-950 font-medium flex items-center gap-1 cursor-pointer"
                  >
                    <Edit2 className="w-3 h-3" />
                    <span>Correct Intent</span>
                  </button>
                </div>
              ) : (
                <div className="space-y-2 pt-1">
                  <select
                    value={selectedIntentValue}
                    onChange={(e) => setSelectedIntentValue(e.target.value as IntentLabel)}
                    className="w-full text-xs bg-white border border-stone-300 rounded p-1.5 font-mono focus:outline-none"
                  >
                    <option value="DEEP_WORK">DEEP_WORK</option>
                    <option value="LEARNING">LEARNING</option>
                    <option value="DISTRACTION">DISTRACTION</option>
                    <option value="DISTRACTION_BREAK">DISTRACTION_BREAK</option>
                    <option value="COMMUNICATION">COMMUNICATION</option>
                    <option value="AMBIENT">AMBIENT</option>
                    <option value="ADMIN">ADMIN</option>
                  </select>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={handleIntentSave}
                      className="px-3 py-1 bg-emerald-800 text-white rounded text-xs font-medium cursor-pointer"
                    >
                      Save Correction
                    </button>
                    <button
                      onClick={() => setEditingIntent(false)}
                      className="px-2 py-1 bg-stone-200 text-stone-700 rounded text-xs cursor-pointer"
                    >
                      Cancel
                    </button>
                  </div>
                </div>
              )}
            </div>

            {/* Main Window Transitions Breakdown */}
            <div className="space-y-2">
              <div className="text-xs font-semibold text-stone-800 flex items-center justify-between">
                <span>Window Transitions Breakdown</span>
                <span className="text-[11px] font-mono text-stone-500">Dwell duration</span>
              </div>
              <div className="space-y-2 max-h-48 overflow-y-auto pr-1">
                {selectedSession.main_events?.map((ev, i) => (
                  <div
                    key={i}
                    className="p-2.5 rounded bg-stone-50 border border-stone-200 text-xs space-y-1"
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-semibold text-stone-900">{ev.app}</span>
                      <span className="font-mono text-stone-600 font-bold">{ev.dwell_s}s</span>
                    </div>
                    <div className="text-stone-500 truncate text-[11px]">{ev.title}</div>
                  </div>
                ))}
              </div>
            </div>

            {/* Unresolved Threads */}
            {selectedSession.unresolved_threads && selectedSession.unresolved_threads.length > 0 && (
              <div className="space-y-2 p-3 bg-amber-50 rounded-lg border border-amber-200">
                <div className="text-xs font-semibold text-amber-900 flex items-center gap-1.5">
                  <AlertTriangle className="w-3.5 h-3.5 text-amber-700" />
                  <span>Unresolved Cognitive Threads</span>
                </div>
                <ul className="text-xs text-amber-800 space-y-1 list-disc list-inside">
                  {selectedSession.unresolved_threads.map((thread, i) => (
                    <li key={i}>{thread}</li>
                  ))}
                </ul>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
