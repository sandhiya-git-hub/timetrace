import React from 'react';
import { ArrowRight, Clock, Laptop, Lock, LogOut, XCircle } from 'lucide-react';
import { ChunkSummary, DeviceState } from '@shared/types/chronotrace';

interface DeviceLockedViewProps {
  device: DeviceState | null;
  chunks: ChunkSummary[];
  onReconnect: () => void;
  onLogout: () => void;
}

const formatDateTime = (iso?: string | null) => (iso ? new Date(iso).toLocaleString() : 'Never');

const formatDuration = (seconds: number) => {
  const total = Math.round(seconds || 0);
  const m = Math.floor(total / 60);
  const s = total % 60;
  return m > 0 ? `${m}m ${s}s` : `${s}s`;
};

const intentLabel = (intent?: string) =>
  intent ? intent.replace(/_/g, ' ').toLowerCase() : 'unclassified';

/**
 * Shown instead of the dashboard whenever the device is not connected.
 * It lists only activity recorded up to the last successful connection, and
 * is clearly labelled as a snapshot so nothing reads as live.
 */
export const DeviceLockedView: React.FC<DeviceLockedViewProps> = ({
  device,
  chunks,
  onReconnect,
  onLogout,
}) => {
  const isLoading = device === null;
  const snapshot = [...chunks].reverse().slice(0, 25);

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 flex flex-col font-sans">
      <header className="bg-white border-b border-slate-200">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 h-14 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-blue-600 flex items-center justify-center text-white text-sm font-semibold">
              C
            </div>
            <span className="font-semibold text-sm tracking-tight">ChronoTrace</span>
          </div>
          <button
            type="button"
            onClick={onLogout}
            className="inline-flex items-center gap-1.5 text-xs text-slate-500 hover:text-slate-800 cursor-pointer"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>Log out</span>
          </button>
        </div>
      </header>

      <main className="flex-1 w-full max-w-5xl mx-auto px-4 sm:px-6 py-8 space-y-6">
        {/* Lock notice and device status */}
        <section className="bg-white border border-rose-200 rounded-2xl p-6 space-y-5">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-rose-50 border border-rose-200 flex items-center justify-center">
              <Lock className="w-5 h-5 text-rose-600" />
            </div>
            <div>
              <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-rose-50 border border-rose-200 text-rose-700 text-[11px] font-semibold">
                <XCircle className="w-3 h-3" />
                {isLoading ? 'Checking device…' : 'Not Connected'}
              </span>
              <h1 className="text-xl font-bold text-slate-900 mt-1.5">Dashboard locked</h1>
            </div>
          </div>

          <p className="text-sm text-slate-600 leading-relaxed">
            The dashboard is only available while your Windows device is connected. Connect it to resume live
            tracking. Until then, the only activity shown is what was recorded before the last successful connection.
          </p>

          <dl className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
            <div className="p-3 rounded-lg bg-slate-50 border border-slate-200">
              <dt className="text-slate-500 flex items-center gap-1.5">
                <Laptop className="w-3.5 h-3.5" /> Device
              </dt>
              <dd className="font-medium text-slate-900 mt-1">{device?.deviceName || 'Not linked'}</dd>
            </div>
            <div className="p-3 rounded-lg bg-slate-50 border border-slate-200">
              <dt className="text-slate-500 flex items-center gap-1.5">
                <Clock className="w-3.5 h-3.5" /> Last successful connection
              </dt>
              <dd className="font-medium text-slate-900 mt-1">{formatDateTime(device?.lastSuccessfulConnectionAt)}</dd>
            </div>
            <div className="p-3 rounded-lg bg-slate-50 border border-slate-200">
              <dt className="text-slate-500 flex items-center gap-1.5">
                <Clock className="w-3.5 h-3.5" /> Last recorded event
              </dt>
              <dd className="font-medium text-slate-900 mt-1">{device?.lastEventTime || '—'}</dd>
            </div>
          </dl>

          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <p className="text-xs text-slate-500">{device?.statusText}</p>
            <button
              type="button"
              onClick={onReconnect}
              className="inline-flex items-center justify-center gap-2 bg-blue-600 hover:bg-blue-700 text-white font-medium px-5 py-2.5 rounded-xl text-xs shadow-xs transition-colors cursor-pointer"
            >
              <span>Reconnect device</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </section>

        {/* Snapshot of previously recorded activity */}
        <section className="bg-white border border-slate-200 rounded-2xl p-6 space-y-4">
          <div>
            <h2 className="text-sm font-semibold text-slate-900">Previously recorded activity</h2>
            <p className="text-xs text-slate-500 mt-1">
              Snapshot from the last successful connection ({formatDateTime(device?.lastSuccessfulConnectionAt)}).
              This is not live. New activity appears only after the device reconnects.
            </p>
          </div>

          {isLoading ? (
            <p className="text-xs text-slate-500">Loading recorded activity…</p>
          ) : snapshot.length === 0 ? (
            <p className="text-xs text-slate-500">No activity has been recorded from a previous connection.</p>
          ) : (
            <ul className="divide-y divide-slate-100">
              {snapshot.map((c) => (
                <li key={c.chunk_id} className="py-3 flex items-start justify-between gap-4 text-xs">
                  <div className="min-w-0">
                    <div className="font-medium text-slate-900 truncate">
                      {c.primary_task || c.summary || c.anchor_app || 'Recorded session'}
                    </div>
                    <div className="text-slate-500 mt-0.5 font-mono">
                      {c.start_time} · {c.anchor_app || c.main_events?.[0]?.app || 'Unknown app'} · {intentLabel(c.intent)}
                    </div>
                  </div>
                  <div className="text-slate-600 font-mono whitespace-nowrap">{formatDuration(c.duration_s)}</div>
                </li>
              ))}
            </ul>
          )}
        </section>
      </main>
    </div>
  );
};
