import React, { useState, useEffect } from 'react';
import {
  Laptop,
  CheckCircle2,
  X,
  RefreshCw,
  Terminal,
  Activity,
  Check,
  Power,
  Shield,
} from 'lucide-react';
import { DeviceState } from '@shared/types/chronotrace';

interface DeviceModalProps {
  device: DeviceState | null;
  onClose: () => void;
  onRefresh: () => void;
}

export const DeviceModal: React.FC<DeviceModalProps> = ({
  device,
  onClose,
  onRefresh,
}) => {
  const [testing, setTesting] = useState(false);
  const [copied, setCopied] = useState(false);
  const [message, setMessage] = useState<string | null>(null);

  const isConnected = device?.connected === true;
  const appOrigin = typeof window !== 'undefined' ? window.location.origin : 'http://localhost:3000';
  const [agentCommand, setAgentCommand] = useState<string>(
    `cd "$env:USERPROFILE\\Downloads"; python chronotrace_agent.py`
  );

  useEffect(() => {
    fetch('/api/agent/powershell')
      .then((r) => r.json())
      .then((d) => {
        if (d.script) setAgentCommand(d.script);
      })
      .catch(() => {});
  }, []);

  const handleTestConnection = async () => {
    setTesting(true);
    setMessage(null);
    try {
      const res = await fetch('/api/device/connect', { method: 'POST' });
      const data = await res.json();
      onRefresh();
      setMessage(data.message || (data.connected ? 'Agent verified.' : 'Not connected.'));
    } catch {
      setMessage('Could not reach the ChronoTrace server.');
    } finally {
      setTesting(false);
    }
  };

  const handleCopyCmd = () => {
    navigator.clipboard.writeText(agentCommand);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/40 p-4">
      <div className="bg-white border border-slate-200 rounded-2xl max-w-md w-full p-6 shadow-xl relative animate-in fade-in zoom-in-95 duration-150">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <div className="flex items-center gap-2">
            <Laptop className="w-5 h-5 text-blue-600" />
            <h3 className="font-semibold text-slate-900 text-sm">Connected Windows Device</h3>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-600 p-1 rounded cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="space-y-4 my-4 text-xs">
          {/* Status badge and device name */}
          <div className="p-4 rounded-xl bg-slate-50 border border-slate-100 flex items-center justify-between">
            <div>
              <div className="font-semibold text-slate-900 text-sm">
                {device?.deviceName || 'DESKTOP-WIN11-WORKSTATION'}
              </div>
              <div className="text-slate-500 text-[11px] mt-0.5">
                {device?.os || 'Windows 11 Pro 64-bit'}
              </div>
            </div>

            <div
              className={`flex items-center gap-1.5 text-xs font-medium px-2.5 py-1 rounded-full border ${
                isConnected
                  ? 'text-emerald-700 bg-emerald-50 border-emerald-200'
                  : 'text-rose-700 bg-rose-50 border-rose-200'
              }`}
            >
              <span className={`w-2 h-2 rounded-full ${isConnected ? 'bg-emerald-500 animate-pulse' : 'bg-rose-500'}`} />
              <span>{isConnected ? 'Connected' : 'Not Connected'}</span>
            </div>
          </div>

          {/* Details breakdown */}
          <div className="space-y-2 text-slate-600">
            <div className="flex justify-between py-1 border-b border-slate-100">
              <span className="text-slate-500">Agent Version:</span>
              <span className="font-mono font-medium text-slate-900">{device?.agentVersion || '1.2.0'}</span>
            </div>
            <div className="flex justify-between py-1 border-b border-slate-100">
              <span className="text-slate-500">Telemetry Sampling Interval:</span>
              <span className="font-mono font-medium text-slate-900">500ms (pywin32)</span>
            </div>
            <div className="flex justify-between py-1 border-b border-slate-100">
              <span className="text-slate-500">Last Successful Connection:</span>
              <span className="font-mono font-medium text-slate-900">
                {device?.lastSuccessfulConnectionAt ? new Date(device.lastSuccessfulConnectionAt).toLocaleString() : 'Never'}
              </span>
            </div>
            <div className="flex justify-between py-1 border-b border-slate-100">
              <span className="text-slate-500">Total Transitions Recorded:</span>
              <span className="font-mono font-medium text-emerald-700">{device?.eventCount ?? 0} events</span>
            </div>
          </div>

          {/* Local Command Box */}
          <div className="p-3 rounded-xl bg-slate-900 text-slate-100 space-y-2">
            <div className="flex items-center justify-between text-[11px] text-slate-400">
              <span className="flex items-center gap-1">
                <Terminal className="w-3.5 h-3.5" />
                <span>Run Agent Command (PowerShell)</span>
              </span>
              <button
                onClick={handleCopyCmd}
                className="text-blue-400 hover:text-blue-300 font-medium flex items-center gap-1 cursor-pointer"
              >
                {copied ? <Check className="w-3 h-3 text-emerald-400" /> : null}
                <span>{copied ? 'Copied' : 'Copy'}</span>
              </button>
            </div>
            <div className="font-mono text-xs break-all">{agentCommand}</div>
          </div>

          {message && (
            <div className="p-2.5 rounded-lg bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs">
              {message}
            </div>
          )}
        </div>

        <div className="flex items-center justify-between pt-2 border-t border-slate-100">
          <button
            onClick={handleTestConnection}
            disabled={testing}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium bg-blue-600 hover:bg-blue-700 text-white transition-colors cursor-pointer disabled:opacity-60"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${testing ? 'animate-spin' : ''}`} />
            <span>{testing ? 'Pinging Agent...' : 'Test Connection'}</span>
          </button>

          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-lg text-xs font-medium text-slate-600 hover:bg-slate-100 transition-colors cursor-pointer"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
